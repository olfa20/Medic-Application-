const express = require('express');
var mysql = require('mysql');
const bodyparser = require('body-parser');
const app = express();
app.use(express.json());

// connection to the data base

var con = mysql.createConnection({
    host: "localhost",
    user: "user",
    password: "user"
});

con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
});

//Router to get medicament create in search-input
app.post('/informations' , (req, res) => {
const medicsearchInput = req.query.medicSearch;
    con.query('SELECT * from medicupdate WHERE family LIKE "%'+ medicsearchInput +'%" ||  dci LIKE "%'+ medicsearchInput +'%"  || itemname LIKE "%'+ medicsearchInput +'%" || shortname LIKE "%'+ medicsearchInput +'%" ', (err, rows, fields) => {
    if (!err)
    res.send(rows);
    else
    console.log(err);
    })
    } );

//Router to GET specific medicament detail from the MySQL database
app.get('/informations/medicament/:SHORTNAME' , (req, res) => {
    con.query('SELECT * FROM medicupdate WHERE SHORTNAME = ?',[req.params.SHORTNAME], (err, rows, fields) => {
    if (!err)
    res.send(rows);
    else
    console.log(err);
    })
    } );




/*READ Request Handlers
app.get('/', (req, res) => {
    res.send(Home);
});

app.post('/informations/:SHORTNAME', (req, res) => {
    const medic = medic.find(c => c.SHORTNAME === parseInt(req.params.SHORTNAME))

        ;

    if (!medic) res.status(404).send('<h2 style="font-family: Malgun Gothic; color: darkred;">Ooops... Cant find what you are looking for!</h2>');
    res.send(medic);
});

app.post('/informations/:dci'), (req, res) => {

    const medic = medic.find(c => c.dci === parseInt(req.params.dci))

        ;

    if (!medic) res.status(404).send('<h2 style="font-family: Malgun Gothic; color: darkred;">Ooops... Cant find what you are looking for!</h2>');
    res.send(medic);
};
app.post('/informations/:family'), (req, res) => {

    const medic = medic.find(c => c.family === parseInt(req.params.family))

        ;

    if (!medic) res.status(404).send('<h2 style="font-family: Malgun Gothic; color: darkred;">Ooops... Cant find what you are looking for!</h2>');
    res.send(medic);
};
app.post('/informations/:itemname'), (req, res) => {

    const medic = medic.find(c => c.itemname === parseInt(req.params.itemname))

        ;

    if (!medic) res.status(404).send('<h2 style="font-family: Malgun Gothic; color: darkred;">Ooops... Cant find what you are looking for!</h2>');
    res.send(medic);
};







app.post('/informations/medicament/:SHORTNAME', (req, res) => {
    const medic = medic.find(c => c.SHORTNAME === parseInt(req.params.SHORTNAME));

    if (!medic) res.status(404).send('<h2 style="font-family: Malgun Gothic; color: darkred;">Ooops... Cant find what you are looking for!</h2>');
    res.send(medic);
});








//create requete du filtre
con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
    con.query("SELECT * from medicupdate WHERE family LIKE " % paracetamol % " ||  dci LIKE " % paracetamol % "  || itemname LIKE " % paracetamol % " || shortname LIKE " % paracetamol % "", function (err, result) {
        if (err) throw err;
        console.log("Result: " + result);
    });
});




app.get('/api/books', (req,res)=> {
res.send(books);
});*/










//PORT ENVIRONMENT VARIABLE
const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Listening on port ${port}..`));