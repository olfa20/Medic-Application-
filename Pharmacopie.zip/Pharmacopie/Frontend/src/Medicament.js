import React from "react";

import { useLocation } from "react-router-dom";
import "./Medicament.css"
import notice from "./notice.jpg"
const Medicament = () => {
  const medid = useLocation().state.medid;
  const designation = useLocation().state.designation;
  const img = useLocation().state.img;
  const prix = useLocation().state.prix;
  const desciption = useLocation().state.desciption;
  const DCI = useLocation().state.DCI;
  const specialité = useLocation().state.specialité;
  const labo = useLocation().state.labo;
  const forme = useLocation().state.forme;
  const table = useLocation().state.table;
  const PEC = useLocation().state.PEC;
  const Monographie= useLocation().state.Monographie;




  return (
     <div >
          <img src={notice} alt="Doctor" width="1320" height="400px"  />


      <div className="rt">
      <div key={medid}>
        <div>
        <div >
          <h2>Notice </h2>
        </div>
        <div>
        <img id='img1'src={img} alt="" />
        </div>
        </div>
        <div>
        <label>Dénomination:</label>
        <input value={designation}/>
        </div>
        <div>
        <label> DCI:</label>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input value={DCI}/>
        </div>
        
        <div>
        <label> specialité:</label>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input value={specialité}/>
        </div>
        <div>
        <label> Prix de vente:</label>
      &nbsp;&nbsp;&nbsp;

        <input value={prix}/>
        </div>
        <div>
        <label> Laboratoire:</label>
        &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;

        <input value={labo}/>
        </div>
        <div>
        <label> Forme:</label>
        &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp; 
        <input value={forme}/>
        </div>
        <div>
        <label> Tableau:</label>
        &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp; 

        <input value={table}/>
        </div>
        <div>
        <label> PEC:</label>
        &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp; 
        &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;
        <input value={PEC}/>
        </div>
        <div>
        <label> Monographie:</label>
        </div>
        <div>
        <p id="inputtt"> {Monographie}</p>
        </div>
        
        
       


      </div>
    
      </div>
    </div> 
  );
};

export default Medicament;
