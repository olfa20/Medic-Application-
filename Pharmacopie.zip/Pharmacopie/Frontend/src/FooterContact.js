import React, { useState } from 'react'
import "./FooterContact.css"
import oreille from "./oreille.jpg"

const FooterContact = () => {
    const [name,setName]=useState()
    const [email,setEmail]=useState()
    const [number,setNumber]=useState()
    const[subjet,setSubject]=useState()
    const[message,setMessage]=useState()


const verify = () =>{

if(document.getElementById('inputfooter1').value !== "" && document.getElementById('inputfooter2').value !== ""
&& document.getElementById('inputfooter3').value !== "" &&document.getElementById('inputfooter4').value !== ""
&&document.getElementById('inputfooter5').value !== "" )
{
   alert ("Message envoyé avec succées")

}
}



  return (
    <form>
    <div>
<div>
    <h7 id="h7">Drop your message for any info or question</h7>
</div>
<div>
    <input id="inputfooter1" placeholder='Your Name' onChange={(e) => setName(e.target.value)}/>
    <input id="inputfooter2" placeholder='Your email' onChange={(e) => setEmail(e.target.value)}/>


</div>
<div>
<input id="inputfooter3" placeholder='Your phone number'onChange={(e) => setNumber(e.target.value)}/>
<input id="inputfooter4" placeholder='Your subject' onChange={(e) => setSubject(e.target.value)}/>

</div>
<div>
<input id="inputfooter5" placeholder='Write your message...' onChange={(e) => setMessage(e.target.value)}/>

</div>
<div>
    <button id="buttonfooter" onClick={verify}>
        Send Message
    </button>
    
</div>

    </div>
    </form>
  )
}

export default FooterContact