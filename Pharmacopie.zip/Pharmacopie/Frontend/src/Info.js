import React, { useState } from "react";
import Header from "./Header.js";
import { data } from "./data.js";
import { Link, useNavigate } from "react-router-dom";
import BannerInfo from "./BannerInfo.js";
import "./Info.css";

const Info = ({ mymedtype }) => {
  const navigate = useNavigate();
  const [designation, setDesignation] = useState();

/*   const handleLinkClick = (event) => {
    console.log("Anchor element clicked");

    setDesignation(event.currentTarget.value)
    console.log(event.currentTarget.value);
  }; */
  return (
    <div className>
      <BannerInfo/>
      <div className="Info">
        {data &&
          data.map((item) => {
            if (item.famille === mymedtype) {
              return (
                <div key={item.img} className="footer__img">
                  <table>
                <tr>
                  <th>
                  <Link
                    /* value={item}
                    onClick={handleLinkClick} */
                    to={"/informations/medicament"}
                    state={{ medid: item.id ,designation:item.designation, img: item.img, prix:item.prix, 
                      desciption:item.desciption,DCI:item.DCI,specialité:item.specialité,labo:item.labo
                    ,forme:item.forme,table:item.table,PEC:item.PEC,Monographie:item.Monographie                  }}
                  >
                    {item.designation}
                  </Link>
                  </th>
                </tr>
                </table>
              </div>
              );
            } else if (item.designation === mymedtype) {
              return (
                <table key={item.img} className="footer__img">
                <tr>
                  <th>
                  <Link
                    /* value={item}
                    onClick={handleLinkClick} */
                    to={"/informations/medicament"}
                    state={{ medid: item.id ,designation:item.designation, img: item.img, prix:item.prix ,
                      desciption:item.desciption,DCI:item.DCI,specialité:item.specialité,labo:item.labo,
                      forme:item.forme,table:item.table,PEC:item.PEC,Monographie:item.Monographie  }}
                  >
                    {item.designation}
                  </Link>
                  </th>
                </tr>
              </table>
              );
            } else if (item.DCI.includes(mymedtype)) {
              return (
                <table key={item.img} className="footer__img">
                <tr>
                  <th>
                  <Link
                    /* value={item}
                    onClick={handleLinkClick} */
                    to={"/informations/medicament"}
                    state={{ medid: item.id ,designation:item.designation, img: item.img, prix:item.prix , 
                      desciption:item.desciption,DCI:item.DCI,specialité:item.specialité,labo:item.labo,
                      forme:item.forme,table:item.table,PEC:item.PEC ,Monographie:item.Monographie 
                    }}
                  >
                    {item.designation}
                  </Link>
                  </th>
                </tr>
              </table>
              );
            }
          })}
      </div>
    </div>
  );
};

export default Info;
