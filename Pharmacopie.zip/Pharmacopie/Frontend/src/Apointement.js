import React from 'react'
import {    BsTelephoneFill,BsFillPersonFill } from "react-icons/bs";
import {
    ImPhone,
    ImEnvelop,
   
  } from "react-icons/im";

import "./Apointement.css"



const Apointement = () => {

 
  return (
    <div className='Apointement'>
        <div>


        </div>
        <div>
            <h1> Book your appointment</h1>
        </div>
        <div>
        <h5>We will confirm your appointment within 2 hours</h5>
        </div>
        <div className='one'>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <BsFillPersonFill />
        &nbsp;&nbsp;&nbsp;&nbsp;
            <label>Name</label>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <input placeholder='Enter your name' type="text"/>
        </div>
        &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
        <div className='two'>
        <ImEnvelop/>
        &nbsp;&nbsp;&nbsp;&nbsp;
            <label>Email</label>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <input placeholder='Enter your Email' type="text"/>
        </div>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <div className='three'>
        &nbsp;&nbsp;&nbsp;&nbsp;

        <ImPhone />
        &nbsp;&nbsp;&nbsp;&nbsp;

            <label>phone</label>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <input placeholder='Enter your name' type="text"/>
        </div>
        &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <div className='for'>
            <label>service</label>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <input placeholder='Enter your Email' type="text"/>
        </div>
        <div className='five'>
        &nbsp;&nbsp;&nbsp;&nbsp;
        
            <label>doctor</label>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <input placeholder='Enter your phone' type="text"/>
        </div>
        &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <div className='sex'>
            <label>age</label>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <input placeholder='Enter your Email' type="text"/>
        </div>
        <div>
            <button>Submit</button>
        </div>



    </div>
  )
}

export default Apointement