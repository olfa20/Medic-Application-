import React from "react";
import Info from "../Info";
import Header from "../Header";
import { useState } from "react";
import { useLocation } from "react-router-dom";
import BannerInfo from "../BannerInfo";

const InfoPage = () => {
  const mymedtype = useLocation().state.medtype;

  return (
    <div>
      <Header />
      
      <Info mymedtype={mymedtype} />
    </div>
  );
};

export default InfoPage;
