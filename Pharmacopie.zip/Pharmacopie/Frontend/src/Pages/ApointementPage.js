import React from 'react'
import Apointement from '../Apointement'
import Header from '../Header.js'


const ApointementPage = () => {
  return (
    <div>
        <Header/>
<Apointement/>

    </div>
  )
}

export default ApointementPage