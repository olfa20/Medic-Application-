import React from 'react'
import Header from '../Header';
import Medicament from '../Medicament';
import { useLocation } from "react-router-dom";


const MedicamentPage = () => {
  const mymeddesignation = useLocation().state.meddesignation;



  return (
    <div>
<Header/>
<Medicament  />

    </div>
  )
}

export default MedicamentPage 