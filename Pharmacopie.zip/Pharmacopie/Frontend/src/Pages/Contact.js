import React from 'react'
import HeaderContact from '../HeaderContact'
import Header from '../Header.js'
import FooterContact from '../FooterContact'

const Contact = () => {
  return (
    <div>
      <Header/>
      <HeaderContact/>
      <FooterContact/>
    </div>
  )
}

export default Contact