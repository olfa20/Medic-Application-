import React from 'react'
import Header from '../Header.js'
import Banner from '../Banner.js'
import Sidebar from '../Sidebar.js'

const Home = () => {
  return (
    <>
    <Header/>
    <Banner/>
    <Sidebar/>
    </>
  )
}

export default Home