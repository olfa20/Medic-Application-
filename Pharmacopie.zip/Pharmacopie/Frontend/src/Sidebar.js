import React from 'react'
import "./Sidebar.css"
import { ImPhone, ImLocation } from "react-icons/im";



const Sidebar = () => {
    return (
        <div>
            <div className='emergency'>
                <ImPhone id="mm"/>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         
                <p id="a">Emergency Call</p> <br/>
                <p id="b">+021 72 569 884</p><br/>
                <p id="c">+021 72 589 145</p><br/>
            
       
            <ImLocation id="ll"/>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         
            <p id="d">Location</p><br/>
            <p id="e">2108-267 Bizerte,centre Ville,</p><br/>
            <p id="f"> Cité Farhat Hached</p><br/>
           


</div>
        </div>
    )
}

export default Sidebar