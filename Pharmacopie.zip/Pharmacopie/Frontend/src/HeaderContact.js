import React from 'react'
import Doctor from "./l.jpg"


const ContactForm = () => {
  return (
    
        <div className="head">
      <div className="head-imagee">


        <img src={Doctor} alt="Doctor" border-radius="50%" width="1300px" height="350px" layout="fill" objectFit="cover" />
      </div>
      <div class='text-on-image'>
     </div>
    </div>
  )
}

export default ContactForm