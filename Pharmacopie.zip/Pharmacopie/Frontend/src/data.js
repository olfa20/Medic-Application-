const data =[
    {
      "userId": 1,
      "id": 1,
      "designation": "panadol",
      "DCI": "paracetamol",
      "prix": "5",
      "famille":"Analgésiques",
      "img" : "http://localhost:3000/Paracetamol/panadol.jpg",
      "desciption":"jbcisdcusvdcygvdgchvyzczbzuvdyvchvc",
      "VEI":"E",
      "specialité":"hydl",
      "labo": "adweya",
      "forme":"hdjud",
      "table":"njdl",
      "PEC": "5.5",
      "Monographie": "nbxncskdcijxcbjsdhkcbzskdnbchdbjdcbnsjzjjd",

      
    },
    {
      "userId": 1,
      "id": 2,
      "designation": "doliprane",
      "DCI":["hhh","paracetamol"],
      "famille":"Analgésiques",
      "img" : "http://localhost:3000/Paracetamol/doliprane.jpg",
      "desciption":"jbcisdcusvdcygvdgchvyzczbkddddddddddddzuvdyvchvc",
      "prix": "5",
      "VEI":"E",
      "specialité":"hydl",
      "labo": "adweya",
      "forme":"hdjud",
      "table":"njdl",
      "PEC": "5.5",
      "Monographie": "nbxncskdcijxcbjsdhkcbzskdnbchdbjdcbnsjzjjd",



    
    },

    {
      "userId": 1,
      "id": 3,
      "designation": "eferalgon",
      "DCI": "paracetamol",
      "famille":"Analgésiques",
      "img" : "http://localhost:3000/Paracetamol/efferalgon.jpg",
      "desciption":"jbcisdcusvdcygvdgchvyzczbzuvdyvchvc",
      "prix": "5",
      "VEI":"E",
      "specialité":"hydl",
      "labo": "adweya",
      "forme":"hdjud",
      "table":"njdl",
      "PEC": "5.5",
      "Monographie": "nbxncskdcijxcbjsdhkcbzskdnbchdbjdcbnsjzjjd",



      

    },
    {
        "userId": 1,
        "id": 4,
        "designation": "antibiotique",
        "DCI": "jjj",
        "famille":"Antibiotiques et Antibactériens",
        "img" : "",
        "desciption":"jbcisdcusvdcygvdgchvyzczbzuvdyvchvc",
        "prix": "5",
        "VEI":"E",
      "specialité":"hydl",
      "labo": "adweya",
      "forme":"hdjud",
      "table":"njdl",
      "PEC": "5.5",
      "Monographie": "nbxncskdcijxcbjsdhkcbzskdnbchdbjdcbnsjzjjd",



        
  
      },
      {
        "userId": 1,
        "id": 5,
        "designation": "antibiothique2",
        "DCI": "jjj",
        "famille":"Antibiotiques et Antibactériens",
        "img" : "http://localhost:3000/Sport/9.jpg",
        "desciption":"jbcisdcusvdcygvdgchvyzczbzuvdyvchvc",
        "prix": "5",
        "VEI":"E",
      "specialité":"hydl",
      "labo": "adweya",
      "forme":"hdjud",
      "table":"njdl",
      "PEC": "5.5",
      "Monographie": "nbxncskdcijxcbjsdhkcbzskdnbchdbjdcbnsjzjjd",



        
  
      },

















    

  
]

export {data}