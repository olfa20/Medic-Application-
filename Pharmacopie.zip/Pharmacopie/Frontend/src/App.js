import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './Pages/Home';
import InfoPage from "./Pages/InfoPage"
import Medicament from './Medicament';
import Contact from './Pages/Contact';
import Service from './Pages/Service';
import ApointementPage from './Pages/ApointementPage';
import MedicamentPage from './Pages/MedicamentPage';

function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route  path='/' element={<Home/>}/>
      <Route  path="/informations" element={<InfoPage/>} />
      <Route  path="/informations/medicament" element={<MedicamentPage />} />
      <Route  path="/contact" element={<Contact/>} />
      <Route  path="/service" element={<Service/>} />
      <Route  path="/appointement" element={<ApointementPage/>} />




    </Routes>
    
    </BrowserRouter>

  )
}

export default App;
