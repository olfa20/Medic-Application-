import React from 'react'
import "./Banner.css"
import Doctor from "./Doctor.jpg"
import { Link, useNavigate } from "react-router-dom";

const Banner = () => {

  const navigate = useNavigate();
  const aller = () =>{
    let path = `/appointement`;
      navigate(path);
  }

  

  
  return (
    <div className="head-text">
      <div className="head-image">


        <img src={Doctor} alt="Doctor" width="1350px" height="500px" layout="fill" objectFit="cover" />
      </div>
      <div class='text-on-image'>
        <h3> We Always Provide Best Services  </h3>
        <div>
          <p id="par">Bienvenue au site web Medic qui vous vous fournit des informations
            detaillées concernant la pharmacopée Tunisienne</p>
        </div>

        <button id="cc" onClick={aller}> Get Appointement</button>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <button id="ff">Learn More</button>
      </div>
    </div>


  )
}

export default Banner