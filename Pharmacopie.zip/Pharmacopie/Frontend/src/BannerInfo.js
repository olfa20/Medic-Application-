import React from 'react'
import hh from "./hh.jpg"

const BannerInfo = () => {
  return (
    <div>


    <img src={hh} alt="Doctor" width="1320" height="380px"  />
  </div>
  )
}

export default BannerInfo