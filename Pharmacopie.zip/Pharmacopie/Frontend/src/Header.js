import React, { useState } from "react";
import "./Header.css";
import {
  ImPhone,
  ImEnvelop,
  ImLocation,
  ImFacebook2,
  ImInstagram,
  ImTwitter,
  ImLinkedin,
} from "react-icons/im";

import { FiSearch } from "react-icons/fi";
import { Link, useNavigate } from "react-router-dom";

const Header = () => {
  const navigate = useNavigate();
  const [searchInput, setSearchInput] = useState("am");

/*   const recherche = () => {
    {
      let path = `Informations/${searchInput}`;
      navigate(path);
    }
  }; */
  const Home = () =>{
    let path = `/`;
      navigate(path);
  }
  const contact = () =>{
    let path = `/contact`;
      navigate(path);
  }
  const service = () =>{
    let path = `/service`;
      navigate(path);
  }

  return (
    <div>
      <div className="cols">
        &nbsp;&nbsp;&nbsp;&nbsp;
        <ImPhone color="#000080" id="ImPhone" />
        <p id="p1"> Call : +72532775</p>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <ImEnvelop color="#000080" />
        <p> hello@pharamcopee.com</p>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <ImLocation color="#000080" />
        <p>177 cite hached</p>
        &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <ImFacebook2 color="#000080" size="25px" id="ImFacebook2" />
        &nbsp;&nbsp;&nbsp;&nbsp;
        <ImTwitter color="#000080" size="25px" id="ImTwitter" />
        &nbsp;&nbsp;&nbsp;&nbsp;
        <ImLinkedin color="#000080" size="25px" id="ImLinkedin" />
        &nbsp;&nbsp;&nbsp;&nbsp;
        <ImInstagram color="#000080" size="25px" id="ImInstagram" />
      </div>
      <hr color="#c0c0c0" id="hr" />
      <div className="ll">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <button id="button1" onClick={Home}> Home</button>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <button id="button2" onClick={service}>Services</button>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <button id="button3">Doctors</button>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <button id="button4" onClick={contact}>Contact</button>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input
          placeholder="Search..."
          type="texte"
          id="input88"
          onChange={(e) => setSearchInput(e.target.value)}
        />
        <Link
          to={"/informations"}
          state={{medtype: searchInput}}
        > 
         <FiSearch id="FiSearch" /></Link>
      </div>
    </div>
  );
};
export default Header;
